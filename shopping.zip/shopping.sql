-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2024 at 04:36 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `creationDate`, `updationDate`) VALUES
(1, 'admin', 'e807f1fcf82d132f9bb018ca6738a19f', '2017-01-24 16:21:18', '07-05-2024 04:56:55 PM');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `categoryName` varchar(255) DEFAULT NULL,
  `categoryDescription` longtext DEFAULT NULL,
  `updationDate` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `categoryName`, `categoryDescription`, `updationDate`) VALUES
(3, 'Main Food', 'Main food served in cafe 2 for lunch', '07-05-2024 05:00:49 PM'),
(4, 'Desserts', '', '07-05-2024 01:07:43 PM'),
(5, 'Drinks', '', '07-05-2024 01:07:58 PM'),
(6, 'Snacks', '', '07-05-2024 01:08:14 PM');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `productId` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `orderDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `paymentMethod` varchar(50) DEFAULT NULL,
  `orderStatus` varchar(55) DEFAULT NULL,
  `orderId` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `productId`, `quantity`, `orderDate`, `paymentMethod`, `orderStatus`, `orderId`) VALUES
(1, '3', 1, '2024-04-07 18:32:57', 'Cash', NULL, ''),
(7, '2', 1, '2024-05-07 08:41:19', 'PayPal', NULL, ''),
(8, '1', 1, '2024-05-07 08:44:43', 'CASH', NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `productName` varchar(255) DEFAULT NULL,
  `cafeName` varchar(255) NOT NULL,
  `productPrice` int(11) DEFAULT NULL,
  `productDescription` longtext DEFAULT NULL,
  `productImage1` varchar(255) DEFAULT NULL,
  `productAvailability` varchar(255) DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category`, `productName`, `cafeName`, `productPrice`, `productDescription`, `productImage1`, `productAvailability`, `postingDate`, `updationDate`) VALUES
(23, 4, 'Cake', 'Library cafe ', 3, '<i>Chocolate </i>cake&nbsp;', 'chocolate_fudge_cake_1678297831860_500.jpg', 'Available', '2024-05-07 12:40:13', NULL),
(24, 5, 'chocolate Milk Shake', 'Art Cafe', 6, '350 ml milkShake', 'oreo_milkshake_1678733435017_500.jpg', 'Not Available', '2024-05-07 12:47:22', NULL),
(25, 5, 'Strawberry milkShake', 'library Cafe', 6, '<span style=\"color: rgb(0, 0, 0); font-size: 14px; text-align: justify;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec aliquet lacinia nunc ut euismod. Nunc egestas bibendum nisi, nec rhoncus ante auctor sit amet. Donec sed consequat risus. Aenean iaculis blandit eros, at tincidunt orci volutpat at. Duis ultricies dolor et mauris imperdiet, sit amet volutpat dui efficitur. Ut aliquam venenatis dignissim. Cras congue diam et erat tincidunt tempor. Sed non orci nulla. Fusce mi nulla, venenatis accumsan hendrerit sed, commodo nec sapien. Quisque pharetra lorem mauris, pulvinar vestibulum augue pellentesque et. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec a porttitor lorem. Nam volutpat justo sit amet massa finibus auctor. Sed augue nulla, ultricies at sollicitudin sed, tempor in ligula.</span>												', 'snickers_milkshake_1678832722981_500.jpg', 'Available', '2024-05-07 12:48:32', NULL),
(26, 4, 'Ice cream', 'cafe 2', 7, '<div id=\"lipsum\" style=\"margin: 0px; padding: 0px; text-align: justify; color: rgb(0, 0, 0); font-size: 14px;\"><p style=\"margin-bottom: 15px; padding: 0px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin quis.</p><div><br></div></div>												', 'new_project_-_2023-05-19t203145_1684508530918_500.jpg', 'Available', '2024-05-07 12:49:19', NULL),
(27, 4, 'pancake', 'Art Cafe', 8, '<ol><li style=\"margin: 0px; padding: 0px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li><li style=\"margin: 0px; padding: 0px;\">Phasellus ultricies mi nec fermentum tincidunt.</li><li style=\"margin: 0px; padding: 0px;\">Nam aliquet dui nec augue vestibulum dictum.</li></ol>												', 'jam_roly_poly_1685370440937_500.jpg', 'Available', '2024-05-07 12:50:16', NULL),
(28, 6, 'Chips', 'Cafe 2', 9, '<ol><li><span style=\"color: rgb(0, 0, 0); font-size: 14px; text-align: justify;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span></li><li><span style=\"color: rgb(0, 0, 0); font-size: 14px; text-align: justify;\">Phasellus ultricies mi nec fermentum tincidunt.</span></li><li><span style=\"color: rgb(0, 0, 0); font-size: 14px; text-align: justify;\">Nam aliquet dui nec augue vestibulum dictum</span></li></ol>												', '6pcs_mozzarella_sticks_1678882700067_500.jpg', 'Available', '2024-05-07 12:50:57', NULL),
(29, 6, 'Onion', 'Art Cafe', 3, '<ul style=\"margin-bottom: 0px; margin-left: 0px; color: rgb(0, 0, 0); font-size: 14px; text-align: justify;\"><li style=\"margin: 0px; padding: 0px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li></ul><ol><li><span style=\"color: rgb(0, 0, 0); font-size: 14px; text-align: justify;\">Phasellus ultricies mi nec fermentum tincidunt.</span></li><li style=\"margin: 0px; padding: 0px;\">Nam aliquet dui nec augue vestibulum dictum</li></ol>												', 'fried_onions_1684155957762_500.jpg', 'Available', '2024-05-07 12:51:30', NULL),
(30, 3, 'Salad', 'Library Cafe', 8, '<ul style=\"margin-bottom: 0px; margin-left: 0px; color: rgb(0, 0, 0); font-size: 14px; text-align: justify;\"><li style=\"margin: 0px; padding: 0px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li><li style=\"margin: 0px; padding: 0px;\">Phasellus ultricies mi nec fermentum tincidunt.</li><li style=\"margin: 0px; padding: 0px;\">Nam aliquet dui nec augue vestibulum dictum</li></ul>												', 'salad_1678794929442_500.jpg', 'Available', '2024-05-07 12:52:03', NULL),
(31, 5, 'Coka', 'Cafe 2', 2, '												', 'cokr_1683126137755_1687176893336_500.jpg', 'Available', '2024-05-07 12:52:32', NULL),
(32, 3, 'Wrap', 'Cafe 2', 10, '<ul style=\"margin-bottom: 0px; margin-left: 0px; color: rgb(0, 0, 0); font-size: 14px; text-align: justify;\"><li style=\"margin: 0px; padding: 0px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li><li style=\"margin: 0px; padding: 0px;\">Phasellus ultricies mi nec fermentum tincidunt.</li><li style=\"margin: 0px; padding: 0px;\">Nam aliquet dui nec augue vestibulum dictum</li></ul>												', 'veg_samosa_1679053078873_500.jpg', 'Available', '2024-05-07 13:43:16', NULL),
(33, 3, 'Pasta', 'Lib Cafe', 16, '<ol><li style=\"margin: 0px; padding: 0px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li></ol>												', 'garlic_mushroom_with_cheese_1685645997866_500.jpg', 'Available', '2024-05-07 13:43:57', NULL),
(34, 3, 'Soup', 'Cafe 2', 4, '<ul style=\"margin-bottom: 0px; margin-left: 0px; color: rgb(0, 0, 0); font-size: 14px; text-align: justify;\"><li style=\"margin: 0px; padding: 0px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li><li style=\"margin: 0px; padding: 0px;\">Phasellus ultricies mi nec fermentum tincidunt.</li><li style=\"margin: 0px; padding: 0px;\">Nam aliquet dui nec augue vestibulum dictum</li></ul>												', 'coleslaw_1678297951260_500.jpg', 'Available', '2024-05-07 13:44:18', NULL),
(35, 3, 'Pasta', 'Cafe 2', 4, '<ul style=\"margin-bottom: 0px; margin-left: 0px; color: rgb(0, 0, 0); font-size: 14px; text-align: justify;\"><li style=\"margin: 0px; padding: 0px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li><li style=\"margin: 0px; padding: 0px;\">Phasellus ultricies mi nec fermentum tincidunt.</li><li style=\"margin: 0px; padding: 0px;\">Nam aliquet dui nec augue vestibulum dictum</li></ul>												', 'new_project_-_2023-05-24t223030_1684947850981_500.jpg', 'Available', '2024-05-07 13:44:37', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
